package com.springbook.biz.board;

import java.util.List;

public interface BoardService { //이 보드서비스는 그저 인터페이스고
	// BoardServiceImpl.java가 보드서비스의 실 구현 객체(클래스)다
	// CRUD 기능의 메소드 구현
	// 글 등록
	void insertBoard(BoardVO vo);

	// 글 수정
	void updateBoard(BoardVO vo);

	// 글 삭제
	void deleteBoard(BoardVO vo);

	// 글 상세 조회
	BoardVO getBoard(BoardVO vo);

	// 글 목록 조회
	List<BoardVO> getBoardList(BoardVO vo);
}
